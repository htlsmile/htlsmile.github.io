﻿------------------
Please open *RunMe.bat* to open application.

If you want to open Office Tool Plus directly, please install .NET 5 Desktop Runtime x86, NOT x64!
Download link: https://dotnet.microsoft.com/download/dotnet/current/runtime
------------------
请打开 RunMe.bat 以运行 Office Tool Plus.

如果你想直接双击打开 Office Tool Plus，请确保你安装了 .NET 5 Desktop Runtime x86，注意不是 x64!
下载链接：https://dotnet.microsoft.com/download/dotnet/current/runtime
------------------
請打開 RunMe.bat 來快速執行 Office Tool Plus.

如果您想要直接開啟 Office Tool Plus，請確保您已安裝了 .NET 5 Desktop Runtime x86，要注意不是 x64 版！
下載連結：https://dotnet.microsoft.com/download/dotnet/current/runtime